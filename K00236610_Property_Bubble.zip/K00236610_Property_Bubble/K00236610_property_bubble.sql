CREATE DATABASE  IF NOT EXISTS `k00236610_propertybubble` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `k00236610_propertybubble`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: k00236610_propertybubble
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.8-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `accepted_auctions`
--

DROP TABLE IF EXISTS `accepted_auctions`;
/*!50001 DROP VIEW IF EXISTS `accepted_auctions`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `accepted_auctions` AS SELECT 
 1 AS `AuctionID`,
 1 AS `WinningBid`,
 1 AS `StopTime`,
 1 AS `AuctionStatus`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `auction`
--

DROP TABLE IF EXISTS `auction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction` (
  `AuctionID` int(11) NOT NULL,
  `min_price` varchar(45) DEFAULT NULL,
  `WinningBid` varchar(45) DEFAULT NULL,
  `StartTime` varchar(45) DEFAULT NULL,
  `StopTime` varchar(45) DEFAULT NULL,
  `AuctionStatus` varchar(45) DEFAULT NULL,
  `EmployeeID` int(11) NOT NULL,
  PRIMARY KEY (`AuctionID`),
  KEY `fk_auction_estateagents1_idx` (`EmployeeID`),
  CONSTRAINT `EmployeeID` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction`
--

LOCK TABLES `auction` WRITE;
/*!40000 ALTER TABLE `auction` DISABLE KEYS */;
INSERT INTO `auction` VALUES (45225,'€1000000.00','€1344000.00','11:38 AM','2:19 PM','0',5943697),(148028,'€15000.00','€21000.00','4:07 AM','6:43 PM','1',59432109),(564260,'€80000.00','€170000.00','3:55 PM','7:12 PM','1',5909452),(627254,'€500000.00','€728000.00','11:38 AM','11:00 PM','0',59782319),(744577,'€100000.00','€220000.00','8:13 AM','2:19 PM','1',596309786),(3554845,'€70000.00','€100000.00','11:30 AM','8:30 PM','1',902353),(5700578,'€700000.00','€980000.00','8:24 AM','10:40 PM','0',5934520),(8169595,'€20000.00','€50000.00','4:16 AM','5:53 PM','1',598424),(8602055,'€50000.00','€120000.00','9:08 AM','8:31 PM','1',594535),(8910201,'€3000000.00','€5200000.00','7:19 AM','5:58 PM','1',5940686),(8918731,'€40000.00','€105000.00','5:00 AM','11:29 PM','0',5068844);
/*!40000 ALTER TABLE `auction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bids`
--

DROP TABLE IF EXISTS `bids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bids` (
  `BidID` int(11) NOT NULL,
  `price` varchar(45) DEFAULT NULL,
  `HighestBid` varchar(45) DEFAULT NULL,
  `Bidstatus` varchar(45) DEFAULT NULL,
  `BidTime` varchar(45) DEFAULT NULL,
  `CustomersID` int(11) NOT NULL,
  `AuctionID` int(11) NOT NULL,
  PRIMARY KEY (`BidID`),
  KEY `fk_bids_customers1_idx` (`CustomersID`),
  KEY `fk_bids_auction1_idx` (`AuctionID`),
  CONSTRAINT `fk_bids_auction1` FOREIGN KEY (`AuctionID`) REFERENCES `auction` (`AuctionID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_bids_customers1` FOREIGN KEY (`CustomersID`) REFERENCES `customers` (`CustomerID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bids`
--

LOCK TABLES `bids` WRITE;
/*!40000 ALTER TABLE `bids` DISABLE KEYS */;
INSERT INTO `bids` VALUES (506363,'€50000.00','€850000','Accepted','12:16 AM',56742754,8602055),(525356,'€1000000.00','€1240000.00','Accepted','6:37 PM',555684356,45225),(783456,'€700000.00','€100000.00','Accepted','7:15 PM',6472563,3554845),(1004674,'€100000.00','€195000.00','Accepted','4:59 AM',5534644,744577),(3735566,'€500000.00','€680000.00','Rejected','6:52 PM',5255896,627254),(5364557,'€80000.00','€125000.00','Rejected','3:41 PM',5040082,564260),(5543535,'€20000.00','€36000.00','Under Consideration’','8:22 AM',55536544,8169595),(5746474,'€15000.00','€19500.00','Rejected','5:55 PM',550400,148028),(59354646,'€40000.00','€91000.00','Withdrawn','7:57 PM',550012,8918731),(74536467,'€700000.00','€886000.00','Withdrawn','9:42 AM',55554646,5700578),(80546746,'€3000000.00','€4580000.00','Under Consideration’','12:21 AM',5135510,8910201);
/*!40000 ALTER TABLE `bids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branch` (
  `BranchID` int(11) NOT NULL,
  `Address` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  `Country` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`BranchID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` VALUES (935367,'Roxboro Limerick City','Limerick','Ireland'),(2217864,'187 Oxford Parkway','Yanji','China'),(2635007,'68 Anthes Parkway','Dzerzhinskiy','Russia'),(2670920,'93 Ruskin Center','Tessaoua','Niger'),(2800874,'139 Ridgeview Hill','Monte de Fralães','Portugal'),(2833259,'123 Eggendart Avenue','Jiaobei','China'),(2976402,'40 Corben Circle','Fucheng','China'),(26327490,'1770 Maple Wood Drive','Shahe','China'),(27653095,'90 Loomis Street','Chugay','Peru'),(28053208,'53 West Circle','Kuanchuan','China'),(28535340,'035 Macpherson Plaza','Abelheira','Portugal');
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `CustomerID` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `userpassword` varchar(45) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `firstName` varchar(45) DEFAULT NULL,
  `surName` varchar(45) DEFAULT NULL,
  `Mobile` varchar(45) DEFAULT NULL,
  `Address` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  `Country` varchar(45) DEFAULT NULL,
  `AccountStatus` tinyint(1) DEFAULT NULL,
  `Employees_EmployeeID` int(11) NOT NULL,
  PRIMARY KEY (`CustomerID`),
  KEY `fk_customers_Employees1_idx` (`Employees_EmployeeID`),
  CONSTRAINT `fk_customers_Employees1` FOREIGN KEY (`Employees_EmployeeID`) REFERENCES `employees` (`EmployeeID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (550012,'jseth9','8pWn40OUME','jseth9@google.es','Jemimah','Seth','155-380-5003','75 Muir Terrace','Dolní Rychnov','Czech Republic',1,5068844),(550400,'ssopp6','hy9dxg','ssopp6@hatena.ne.jp','Shelby','Sopp','420-355-5025','57995 Dovetail Alley','Dalai','China',0,59432109),(5040082,'lprugel1','mezis7cp4Vh','lprugel1@eepurl.com','Latrina','Prugel','904-354-3934','860 Cottonwood Way','El Obeid','Sudan',1,5909452),(5135510,'giorizzo8','J1hbLz7S8','giorizzo8@icq.com','Gothart','Iorizzo','193-699-6016','297 Carey Way','Xia Zanggor','China',1,5940686),(5255896,'lrannie3','Cx9Mhvw','lrannie3@hexun.com','Lovell','Rannie','372-669-9414','8 Anderson Center','Yuanyang','China',0,59782319),(5534644,'seckford2','7tDwLM','seckford2@edublogs.org','Sidnee','Eckford','959-443-4028','984 Comanche Lane','Bacheng','China',0,596309786),(6472563,'patkelly0','xCbn127ER','patkelly@gmail.com','Pat','Kelly','086-423-8596','Castletroy Limerick','Limerick','Ireland',1,594535),(55536544,'agaspar5','xNN2Qv','agaspar5@tinyurl.com','Anette','Gaspar','903-805-4948','2 Sunbrook Place','Tugusirna','Indonesia',0,598424),(55554646,'ghackwell7','O0QVxR2MrJc','ghackwell7@go.com','Grannie','Hackwell','703-517-2147','6478 Hintze Crossing','Roubaix','France',1,5934520),(56742754,'gliepina0','xYIQ0rtpC','gliepina0@ameblo.jp','Gerrie','Liepina','619-971-9296','49702 Fair Oaks Crossing','Utama Wetan','Indonesia',1,594535),(555684356,'sbrader4','1VAs94XPrB','sbrader4@tuttocitta.it','Shina','Brader','867-786-7087','18362 Lakewood Gardens Place','Xiangdian','China',1,5943697);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `EmployeeID` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `userpassword` varchar(45) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `firstName` varchar(45) DEFAULT NULL,
  `surName` varchar(45) DEFAULT NULL,
  `Mobile` varchar(45) DEFAULT NULL,
  `Address` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  `Country` varchar(45) DEFAULT NULL,
  `EmployeeTypeID` int(11) NOT NULL,
  `Branch_BranchID` int(11) NOT NULL,
  PRIMARY KEY (`EmployeeID`),
  KEY `fk_Employees_EmployeeType1_idx` (`EmployeeTypeID`),
  KEY `fk_Employees_Branch1_idx` (`Branch_BranchID`),
  CONSTRAINT `fk_Employees_Branch1` FOREIGN KEY (`Branch_BranchID`) REFERENCES `branch` (`BranchID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Employees_EmployeeType1` FOREIGN KEY (`EmployeeTypeID`) REFERENCES `employeetype` (`EmployeeTypeID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (594535,'bbourgour0','F3p9B1','bbourgour0@discuz.net','Berny','Bourgour','234-262-5675','01199 Knutson Center','Paraíso','Panama',3035645,26327490),(598424,'ccoath5','qba0jnXP18J','ccoath5@github.io','Claiborne','Coath','743-913-0246','434 Kipling Terrace','Yoiqag','China',3057567,27653095),(902353,'johnhickey12','B34Mn12','johnhickey@gmail.com','John','Hickey','085-262-8541','Moylish Limerick City','Limerick','Ireland',347949,935367),(5068844,'rellam9','9IJYOJ6al','rellam9@g.co','Ruthy','Ellam','677-649-4744','5319 Ronald Regan Crossing','Bafia','Cameroon',302356,2833259),(5909452,'ldodwell1','E6npOGytcvs','ldodwell1@dagondesign.com','Leora','Dodwell','817-476-8436','10 Roxbury Avenue','Āq Qāyeh','Iran',3064785,2217864),(5934520,'diohananof7','SRlNngmGSo','diohananof7@imageshack.us','Derick','Iohananof','490-189-8137','40 Graedel Crossing','Akwanga','Nigeria',304675,2635007),(5940686,'cbaigent8','C8KTo3','cbaigent8@elpais.com','Carly','Baigent','386-595-2614','9 Birchwood Junction','Dengmu','China',306434,28053208),(5943697,'cbishop4','WbCWxoT','cbishop4@trellian.com','Carlene','Bishop','459-876-0103','36 Lyons Hill','Wiwilí','Nicaragua',30142456,2800874),(59432109,'bobell6','SYi7wi7bvm','bobell6@cmu.edu','Brittani','Obell','968-753-5212','45 Lakeland Crossing','Solna','Sweden',302353,28535340),(59782319,'lsawter3','ykLDSTygwZN','lsawter3@sphinn.com','Ludwig','Sawter','795-688-6134','9017 Holy Cross Crossing','Sabóia','Portugal',3064352,2976402),(596309786,'ggrammer2','S2aSJERf5I','ggrammer2@gravatar.com','George','Grammer','645-713-9180','80 Katie Road','Gonghe','China',30053631,2670920);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employeetype`
--

DROP TABLE IF EXISTS `employeetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employeetype` (
  `EmployeeTypeID` int(11) NOT NULL,
  `EmployeeType` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`EmployeeTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employeetype`
--

LOCK TABLES `employeetype` WRITE;
/*!40000 ALTER TABLE `employeetype` DISABLE KEYS */;
INSERT INTO `employeetype` VALUES (302353,'Estate Agent'),(302356,'Estate Agent'),(304675,'Estate Agent'),(306434,'Estate Agent'),(347949,'Estate Agent'),(3035645,'Estate Agent'),(3057567,'Estate Agent'),(3064352,'Estate Agent'),(3064785,'Estate Agent'),(30053631,'Estate Agent'),(30142456,'Estate Agent');
/*!40000 ALTER TABLE `employeetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `properties`
--

DROP TABLE IF EXISTS `properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `properties` (
  `PropertyID` int(11) NOT NULL,
  `Country` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  `Price` varchar(45) DEFAULT NULL,
  `PropertyStatus` varchar(45) DEFAULT NULL,
  `facilities` varchar(45) DEFAULT NULL,
  `CustomerID` int(11) NOT NULL,
  `Address` varchar(45) DEFAULT NULL,
  `PropertyTypeID` int(11) NOT NULL,
  PRIMARY KEY (`PropertyID`),
  KEY `fk_properties_customers1_idx` (`CustomerID`),
  KEY `fk_properties_PropertyType1_idx` (`PropertyTypeID`),
  CONSTRAINT `fk_properties_PropertyType1` FOREIGN KEY (`PropertyTypeID`) REFERENCES `propertytype` (`PropertyTypeID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_properties_customers1` FOREIGN KEY (`CustomerID`) REFERENCES `customers` (`CustomerID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `properties`
--

LOCK TABLES `properties` WRITE;
/*!40000 ALTER TABLE `properties` DISABLE KEYS */;
INSERT INTO `properties` VALUES (113535,'Philippines','Navotas','€500000.00','ForSale','4 Bedrooms',5255896,'91 Dennis Circle',84242426),(298695,'Japan','Tagawa','€700000.00','ForSale','4 Bedrooms and Garage',55554646,'35472 Bay Road',403535),(323564,'China','Cishan','€80000.00','Sold','3 Bedrooms and Garage',5040082,'6741 Alpine Trail',646353),(825353,'Sweden','Stenungsund','€1000000.00','ForSale','5 Bedrooms with En-suite and Garage',555684356,'10573 Meadow Ridge Point',99476746),(876534,'Ireland','Limerick','€700000.00','Sold','3 Bedrooms',6472563,'Moylish Limerick City',457783),(897577,'China','Wangmang','€3000000.00','Sold','10 Bedrooms with En-suite and 2 Garages',5135510,'46847 Melvin Terrace',1853538),(935353,'China','Gaojiazhuang','€50000.00','Sold','2 Bedrooms',56742754,'91236 Thompson Crossing',4764465),(2364326,'Sudan','Tokār','€40000.00','ForSale','2 Bedrooms',550012,'03 Miller Drive',1286607),(3235366,'China','Shanghu','€100000.00','Sold','3 Bedrooms and Garage',5534644,'79397 Moland Avenue',65654),(4646578,'Thailand','Bang Krathum','€20000.00','Sold','1 Bedroom with En-suite',55536544,'80 Lindbergh Junction',51465464),(5807574,'Russia','Kalinovskaya','€15000.00','Sold','1 Bedroom',550400,'04128 Dennis Court',8153535);
/*!40000 ALTER TABLE `properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `properties_has_auction`
--

DROP TABLE IF EXISTS `properties_has_auction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `properties_has_auction` (
  `PropertyID` int(11) NOT NULL,
  `AuctionID` int(11) NOT NULL,
  PRIMARY KEY (`PropertyID`,`AuctionID`),
  KEY `fk_properties_has_auction_auction1_idx` (`AuctionID`),
  KEY `fk_properties_has_auction_properties1_idx` (`PropertyID`),
  CONSTRAINT `fk_properties_has_auction_auction1` FOREIGN KEY (`AuctionID`) REFERENCES `auction` (`AuctionID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_properties_has_auction_properties1` FOREIGN KEY (`PropertyID`) REFERENCES `properties` (`PropertyID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `properties_has_auction`
--

LOCK TABLES `properties_has_auction` WRITE;
/*!40000 ALTER TABLE `properties_has_auction` DISABLE KEYS */;
INSERT INTO `properties_has_auction` VALUES (113535,627254),(298695,5700578),(323564,564260),(825353,45225),(876534,3554845),(897577,8910201),(935353,8602055),(2364326,8918731),(3235366,744577),(4646578,8169595),(5807574,148028);
/*!40000 ALTER TABLE `properties_has_auction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `propertytype`
--

DROP TABLE IF EXISTS `propertytype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `propertytype` (
  `PropertyTypeID` int(11) NOT NULL,
  `PropertyType` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`PropertyTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `propertytype`
--

LOCK TABLES `propertytype` WRITE;
/*!40000 ALTER TABLE `propertytype` DISABLE KEYS */;
INSERT INTO `propertytype` VALUES (65654,'Bungalow'),(403535,'detached'),(457783,'Semidetached'),(646353,'Semidetached'),(1286607,'Apartment'),(1853538,'detached'),(4764465,'Bungalow'),(8153535,'Apartment'),(51465464,'detached'),(84242426,'Semidetached'),(99476746,'Apartment');
/*!40000 ALTER TABLE `propertytype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `tagawa_properties`
--

DROP TABLE IF EXISTS `tagawa_properties`;
/*!50001 DROP VIEW IF EXISTS `tagawa_properties`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `tagawa_properties` AS SELECT 
 1 AS `PropertyID`,
 1 AS `Price`,
 1 AS `PropertyStatus`,
 1 AS `facilities`,
 1 AS `Address`,
 1 AS `City`,
 1 AS `Country`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'k00236610_propertybubble'
--
/*!50003 DROP PROCEDURE IF EXISTS `new_updatebid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `new_updatebid`()
BEGIN
UPDATE bids
SET highestbid = '€850000'
where BidID = 506363;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_addNewData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_addNewData`()
BEGIN
insert into branch values (0935367, 'Roxboro Limerick City', 'Limerick', 'Ireland');
insert into employeetype values (347949, 'Estate Agent');
insert into employees values (902353, 'johnhickey12', 'B34Mn12', 'johnhickey@gmail.com', 'John', 'Hickey', '085-262-8541', 'Moylish Limerick City', 'Limerick', 'Ireland', 347949, 0935367);
insert into customers  values (6472563, 'patkelly0', 'xCbn127ER', 'patkelly@gmail.com', 'Pat', 'Kelly', '086-423-8596', 'Castletroy Limerick', 'Limerick', 'Ireland', true, 594535);
insert into auction  values (3554845, '€70000.00', '€100000.00', '11:30 AM', '8:30 PM', true, 902353);
insert into bids values (783456, '€700000.00','€100000.00' , 'Accepted', '7:15 PM', 6472563, 3554845);
insert into propertytype  values (457783, 'Semidetached');
INSERT INTO properties VALUES(876534, 'Ireland', 'Limerick', '€700000.00', 'Sold', '3 Bedrooms', 6472563, 'Moylish Limerick City', 457783);
insert into properties_has_auction  values (876534,3554845);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_nr_auction` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_nr_auction`(IN AuctionID VARCHAR(5),OUT nrAuctions INT)
BEGIN
	SELECT COUNT(*) INTO nrAuctions
	FROM auction
	WHERE AuctionID=AuctionID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `accepted_auctions`
--

/*!50001 DROP VIEW IF EXISTS `accepted_auctions`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `accepted_auctions` AS select `a`.`AuctionID` AS `AuctionID`,`a`.`WinningBid` AS `WinningBid`,`a`.`StopTime` AS `StopTime`,`a`.`AuctionStatus` AS `AuctionStatus` from `auction` `a` where `a`.`AuctionStatus` like '%1%' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tagawa_properties`
--

/*!50001 DROP VIEW IF EXISTS `tagawa_properties`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `tagawa_properties` AS select `p`.`PropertyID` AS `PropertyID`,`p`.`Price` AS `Price`,`p`.`PropertyStatus` AS `PropertyStatus`,`p`.`facilities` AS `facilities`,`p`.`Address` AS `Address`,`p`.`City` AS `City`,`p`.`Country` AS `Country` from `properties` `p` where `p`.`City` like '%Tagawa%' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-03 14:15:35
