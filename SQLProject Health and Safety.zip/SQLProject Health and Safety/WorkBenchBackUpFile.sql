-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2019 at 09:45 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `h&s`
--

-- --------------------------------------------------------

--
-- Table structure for table `builders`
--

CREATE TABLE `builders` (
  `buildersNo` varchar(5) NOT NULL,
  `fName` varchar(15) NOT NULL,
  `lName` varchar(15) NOT NULL,
  `oPosition` varchar(10) NOT NULL,
  `sex` char(1) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `salary` decimal(9,2) NOT NULL,
  `sitesNo` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `builders`
--

INSERT INTO `builders` (`buildersNo`, `fName`, `lName`, `oPosition`, `sex`, `DOB`, `salary`, `sitesNo`) VALUES
('SA9', 'Mary', 'Howe', 'Assistant', 'F', '1971-02-19', '10000.00', 'B007'),
('SG14', 'David', 'Ford', 'Supervisor', 'M', '1961-11-24', '20000.00', 'B003'),
('SG37', 'Ann', 'Beech', 'Assistant', 'F', '1959-10-11', '15000.00', 'B003'),
('SG5', 'Susan', 'Brand', 'Manager', 'F', '1945-06-03', '25000.00', 'B003'),
('SL21', 'John', 'White', 'Manager', 'M', '1950-10-01', '40000.00', 'B005'),
('SL41', 'Julie', 'Lee', 'Assistant', 'F', '1964-06-13', '10000.00', 'B005');

-- --------------------------------------------------------

--
-- Table structure for table `inspectors`
--

CREATE TABLE `inspectors` (
  `inspectorsNo` varchar(7) NOT NULL,
  `fName` varchar(15) NOT NULL,
  `lName` varchar(15) NOT NULL,
  `telNo` varchar(13) NOT NULL,
  `sex` char(1) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `HireDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inspectors`
--

INSERT INTO `inspectors` (`inspectorsNo`, `fName`, `lName`, `telNo`, `sex`, `DOB`, `HireDate`) VALUES
('CR56', 'Aline', 'Stewart', '0141-848-1825', 'M', '1972-08-12', '1998-05-10'),
('CR62', 'Mary', 'Tregar', '01224-196720', 'F', '1964-01-22', '1989-11-02'),
('CR74', 'Mike', 'Ritchie', '01475-392178', 'M', '1976-05-07', '1998-02-19'),
('CR76', 'John', 'Kay', '0207-774-5632', 'M', '1960-11-01', '1985-07-02');

-- --------------------------------------------------------

--
-- Table structure for table `sites`
--

CREATE TABLE `sites` (
  `sitesNo` char(4) NOT NULL,
  `street` varchar(25) NOT NULL,
  `city` varchar(15) NOT NULL,
  `postcode` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sites`
--

INSERT INTO `sites` (`sitesNo`, `street`, `city`, `postcode`) VALUES
('B002', '123  Bury Rd', 'London', 'SA73 3PX'),
('B003', '127  Holburn Lane', 'Glasgow', 'BD12 8BU'),
('B004', '135  Sloe Lane', 'Bristol', 'S80 1XE'),
('B005', '86  Princes Street', 'London', 'SW2 4LY'),
('B007', '61  Stamford Road', 'Aberdeen', 'ML4 2RD');

-- --------------------------------------------------------

--
-- Table structure for table `visits`
--

CREATE TABLE `visits` (
  `inspectorsNo` varchar(7) NOT NULL,
  `sitesNo` varchar(8) NOT NULL,
  `viewDate` date NOT NULL,
  `comments` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visits`
--

INSERT INTO `visits` (`inspectorsNo`, `sitesNo`, `viewDate`, `comments`) VALUES
('CR56', 'B002', '2001-05-24', 'Not enough safety equipment'),
('CR56', 'B004', '2001-05-26', NULL),
('CR56', 'B007', '2001-04-28', NULL),
('CR62', 'B005', '2001-05-14', 'poor equipment handling'),
('CR76', 'B003', '2001-04-20', 'builders dont have enough training');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `builders`
--
ALTER TABLE `builders`
  ADD PRIMARY KEY (`buildersNo`),
  ADD KEY `Builders_Sites_FK` (`sitesNo`);

--
-- Indexes for table `inspectors`
--
ALTER TABLE `inspectors`
  ADD PRIMARY KEY (`inspectorsNo`);

--
-- Indexes for table `sites`
--
ALTER TABLE `sites`
  ADD PRIMARY KEY (`sitesNo`);

--
-- Indexes for table `visits`
--
ALTER TABLE `visits`
  ADD PRIMARY KEY (`inspectorsNo`,`sitesNo`),
  ADD KEY `Visits_Sites_FK` (`sitesNo`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `builders`
--
ALTER TABLE `builders`
  ADD CONSTRAINT `Builders_Sites_FK` FOREIGN KEY (`sitesNo`) REFERENCES `sites` (`sitesNo`);

--
-- Constraints for table `visits`
--
ALTER TABLE `visits`
  ADD CONSTRAINT `Visits_Inspectors_FK` FOREIGN KEY (`inspectorsNo`) REFERENCES `inspectors` (`inspectorsNo`),
  ADD CONSTRAINT `Visits_Sites_FK` FOREIGN KEY (`sitesNo`) REFERENCES `sites` (`sitesNo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
